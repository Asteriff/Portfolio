This zipped folder contains the model, flask application,
Lab Tasks for COM6033 Applied Artificial Intelligence.

To run the Flasks application, simple run:
python app.py in the terminal making sure your in the right directory.

There is a reference list inside the Notebook and a separate text file.

list of dependencies.
joblib
numpy
pandas
python
flask
matplotlib.pyplot
sklearn
imblearn