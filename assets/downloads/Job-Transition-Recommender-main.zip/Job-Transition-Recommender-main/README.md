# Job-Transition-Recommender
This AI model analyzes your current field, employment level, and skill set to recommend tailored career transition options, helping you find the right next step.

Navigate to app.py and type app run into the terminal. Make sure the file path is pointed towards the folder with app.py inside.
